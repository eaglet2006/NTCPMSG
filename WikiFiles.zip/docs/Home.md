**Project Description**
NTCPMSG is a high performance TCP message send and receive component written by C#.net.
It can provide nearly 2 million asynchronously messages per second between 2 i5 laptop with 1G bps network. WCF (net.tcp and OneWay) only can provide 56,000 messages per second in same environment.
NTcpListener can provide more than 100,000 synchronously messages per second and 20,000 for WCF in same environment.

# Events
## 2012-09-09 1.0.0.0 Released
## 2012-09-24 1.1.1.0 Released
## 2012-10-03 1.2.0.0 Released
## 2013-01-06 1.3.0.0 Rekeased
